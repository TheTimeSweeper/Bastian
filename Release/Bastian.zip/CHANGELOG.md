`2.2.0`
- sots fix

`2.1.0`

- updated punch impact sound effect. fixed weird splash sound effect playing as well.

- item displays implemented

- Did not remove Herobrine

`2.0.5`

- Reverted because i UPLOADED THE WRONG DLL. :pog:

`2.0.4`
- Latest Item Placement Update (More items added onto motel display)

`2.0.3`
- Fixed Changelog Name to display on site
- I am a fool

`2.0.2`
- Added CHANGELOG.md
- Removed Herobrine

`2.0.1`
  - Uploaded proper dll (prior was earlier build, my fault og)

`2.0.0`
  - Full Re-Release (Rework, Animation Changes, Item Placement Start, Risk of Options compat, and more.)

`1.0.1`
  - Minor bug fix (Mod Takedown)

`1.0.0`
  - Initial Release
